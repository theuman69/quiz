const express = require('express');
const Ingredient = require('../models/Ingredient');
const Recipe = require('../models/Recipe');
const checkAdmin = require('../middleware/checkadmin');
const router = express.Router();

router.post('/ingredients', checkAdmin, async (req, res) => {
  try {
    const newIngredient = new Ingredient(req.body);
    await newIngredient.save();
    res.status(201).json(newIngredient);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/recipes', checkAdmin, async (req, res) => {
  try {
    const newRecipe = new Recipe(req.body);
    await newRecipe.save();
    res.status(201).json(newRecipe);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;

