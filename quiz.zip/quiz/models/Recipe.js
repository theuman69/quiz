const mongoose = require('mongoose');
const { Schema } = mongoose;

const recipeSchema = new Schema({
  name: String,
  description: String,
  ingredients: [{ type: Schema.Types.ObjectId, ref: 'Ingredient' }]
});

mongoose.model('Recipe', recipeSchema);


